(function($) {

	$(function() {
	
		new FLBuilderSubscribeForm({
			id: '<?php echo $id ?>'
		});
	});
	
})(jQuery);